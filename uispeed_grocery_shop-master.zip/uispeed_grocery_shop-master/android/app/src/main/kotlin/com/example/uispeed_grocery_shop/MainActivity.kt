package com.example.uispeed_grocery_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
